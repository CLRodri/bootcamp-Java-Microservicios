package com.nttdada.nttdatacentersspringt3RCL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NttdatacentersSpringT3RclApplication {
	
	//Habria que inicializar todos las clases y crear las variables para llamar a los metodos
	//para testear que todo funciona correctamente
	
	public static void main(String[] args) {
		SpringApplication.run(NttdatacentersSpringT3RclApplication.class, args);
	}

}
