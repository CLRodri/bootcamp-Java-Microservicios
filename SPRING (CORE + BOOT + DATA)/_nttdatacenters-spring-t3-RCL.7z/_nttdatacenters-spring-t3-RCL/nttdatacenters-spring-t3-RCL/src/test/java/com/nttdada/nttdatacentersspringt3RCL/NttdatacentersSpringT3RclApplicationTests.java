package com.nttdada.nttdatacentersspringt3RCL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdatacentersSpringT3RclApplicationTests {

	@Test
	void contextLoads() {
	}

}
