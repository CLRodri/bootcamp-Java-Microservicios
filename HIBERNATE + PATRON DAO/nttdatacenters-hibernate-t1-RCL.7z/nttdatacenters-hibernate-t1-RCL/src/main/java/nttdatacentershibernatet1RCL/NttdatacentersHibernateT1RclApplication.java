package nttdatacentershibernatet1RCL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NttdatacentersHibernateT1RclApplication {

	public static void main(String[] args) {
		SpringApplication.run(NttdatacentersHibernateT1RclApplication.class, args);
	}

}
