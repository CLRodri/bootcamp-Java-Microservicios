package nttdatacentershibernatet1RCL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdatacentersHibernateT1RclApplicationTests {

	@Test
	void contextLoads() {
	}

}
